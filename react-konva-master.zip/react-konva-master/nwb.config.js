module.exports = {
  type: 'react-component',
  npm: {
    esModules: false,
    umd: false
  },
  // may be useful for debugging tests
  // karma: {
  //   browsers: ['Chrome']
  // }
};
